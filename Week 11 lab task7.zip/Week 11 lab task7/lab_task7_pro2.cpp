#include<iostream>
using namespace std;
int main()
{
    cout<<"Abu Huraira Shamraiz,73407"<<endl;
    int marks[10];
    float average=0,sum=0;
    for(int i=0;i<10;i++)
    {
        cout<<"Enter the marks of student "<<i+1<<endl;
        cin>>marks[i];
         sum+=marks[i];
    }
    for(int i=0;i<10;i++)
    {
        
        cout<<"Marks of student "<< i+1 <<" is:"<<marks[i]<<endl;
        
    }
    average=sum/10;
    cout<<"Average of student marks is "<<average<<endl;

 return 0;
}