#include<iostream>
using namespace std;
int main()
{
    cout<<"Abu Huraira Shamraiz,73407"<<endl;
    int salaries[6];
    cout<<"Without loop"<<endl;
    cout<<"Salary of 1st Employe"<<endl;
    cin>>salaries[0];
    cout<<"Salary of 2nd Employe"<<endl;
    cin>>salaries[1];
    cout<<"Salary of 3rd Employe"<<endl;
    cin>>salaries[2];
    cout<<"Salary of 4th Employe"<<endl;
    cin>>salaries[3];
    cout<<"Salary of 5th Employe"<<endl;
    cin>>salaries[4];
    cout<<"Salary of 6th Employe"<<endl;
    cin>>salaries[5];
    cout<<"Salaries of All Employes"<<endl;
    cout<<salaries[0]<<endl<<salaries[1]<<endl<<salaries[2]<<endl<<salaries[3]<<endl;
    cout<<salaries[4]<<endl<<salaries[5]<<endl;
    cout<<"Using loop"<<endl;
    for(int i=0;i<6;i++)
    {
        cout<<"Salaries of Employe "<<i+1<<" is:"<<endl;
        cin>>salaries[i];
    }
    for(int i=0;i<6;i++)
    {
        cout<<"Salaries of Employe "<<i+1<<" is:"<<salaries[i]<<endl;
        
    }
 return 0;
}