#include<iostream>
using namespace std;
int main()
{
    int i;
    
    while(i!=(-1))
    {
        cout<<"Enter your number:"<<endl;
        cin>>i;
         cout<<i<<endl;
    }
    cout<<"Invalid number"<<endl;
 return 0;
}