#include<iostream>
using namespace std;
int main()
{
    int seconds,hours,minutes;
    cout<<"Enter the total seconds:"<<endl;
    cin>>seconds;
    hours=seconds/3600;
    int rem_seconds=seconds%3600;
    cout<<hours<<"hr:";
    minutes=seconds/60;
    cout<<minutes<<"min:";
    seconds=rem_seconds%60;
    cout<<seconds<<"sec";
 return 0;
}