#include<iostream>
#include<math.h>
using namespace std;
int main()
{
    char op,type;
    
    float num1,num2;
    cout<<"Enter the first number"<<endl;
    cin>>num1;
    cout<<"Enter the second number"<<endl;
    cin>>num2;
    cout<<"Enter the operator"<<endl;
    cin>>op;
    cout<<"Enter the type (i for integer,f for float)"<<endl;
    cin>>type;
    
   switch(type)
   {
    case'i': 
    switch(op)
    {
        case'+':
        cout<<"Addition of two integer is:"<<num1+num2<<endl;
        break;
          case'*':
        cout<<"multiplication of two integer is:"<<num1*num2<<endl;
        break;
          case'-':
        cout<<"Subtraction of two integer is:"<<num1-num2<<endl;
        break;
          case'/':
        cout<<"Division of two integer is:"<<num1/num2<<endl;
        break;
          case's':
        cout<<"sine of integers is:"<< sin(num1)<<endl<<sin(num2)<<endl;
        break;
         case'c':
        cout<<"cosine of integers is:"<< cos(num1)<<endl<<cos(num2)<<endl;
        break;
         case't':
        cout<<"tangent of integers is:"<< tan(num1)<<endl<<tan(num2)<<endl;
        break;
         case'r':
        cout<<"square root of integers is:"<< sqrt(num1)<<endl<<sqrt(num2)<<endl;
        break;
         case'^':
        cout<<"squareof integer is:"<< num1*num1<<endl<<num2*num2<<endl;
        break;
        case'#':
        cout<<"cube of integer is:"<< num1*num1*num1<<endl<<num2*num2*num2<<endl;
        break;
        default:
        cout<<"Invalid Operator"<<endl;
        break;
    }
        break;
        case'f':
    
        switch(op)
        {
    
        case'+':
        cout<<"Addition of floating point is:"<<num1+num2<<endl;
        break;
          case'*':
        cout<<"multiplication of floating point is:"<<num1*num2<<endl;
        break;
          case'-':
        cout<<"Subtraction of floating point is:"<<num1-num2<<endl;
        break;
          case'/':
        cout<<"Division of floating point is:"<<num1/num2<<endl;
        break;
          case's':
        cout<<"sine of floating point is:"<< sin(num1)<<endl<<sin(num2)<<endl;
        break;
         case'c':
        cout<<"cosine of floating point is:"<< cos(num1)<<endl<<cos(num2)<<endl;
        break;
         case't':
        cout<<"tangent of floating point is:"<< tan(num1)<<endl<<tan(num2)<<endl;
        break;
         case'r':
        cout<<"square root of floating point is:"<< sqrt(num1)<<endl<<sqrt(num2)<<endl;
        break;
         case'^':
        cout<<"squareof floating point is:"<< num1*num1<<endl<<num2*num2<<endl;
        break;
        case'#':
        cout<<"cube of floating point is:"<< num1*num1*num1<<endl<<num2*num2*num2<<endl;
        break;
        default:
        cout<<"Invalid Operator"<<endl;
        break;
         }
        break;
        default:
        cout<<"Invalid type "<<endl;
        break;
        }
        
        



 return 0;
}