#include<iostream>
using namespace std;
int main()
{
    int temperature;
    cout<<"Enter the temperature"<<endl;
    cin>>temperature;
    if(temperature>=35){
    cout<<"It is hot today"<<endl;}
     if(temperature>=25&&temperature<35)
    cout<<"It is pleasent today"<<endl;
      if(temperature<25)
    cout<<"It is cool day"<<endl;
    
    

 return 0;
}