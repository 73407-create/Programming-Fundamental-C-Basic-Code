#include<iostream>
using namespace std;
int main()
{
    char Grade;
    cout<<"Grade of a student"<<endl;
    cin>>Grade;
    
    switch(Grade)
    {
        case 'A':
        case 'a':
        cout<<"Grade is :90-100"<<endl;
        break;
        case 'B':
         case 'b':

        cout<<"Grade is  :80-89 "<<endl;
        break;
        case 'C':
         case 'c':
        cout<<"Grade is :70-79"<<endl;
        break;
        case 'D':
         case 'd':
        cout<<"Grade is :60-69"<<endl;
        break;
        default:
        cout<<"Below 60"<<endl;
        break;

    }
 return 0;
}