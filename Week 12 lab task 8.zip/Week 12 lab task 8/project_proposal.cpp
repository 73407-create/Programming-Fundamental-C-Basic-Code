#include<iostream>
using namespace std;

struct Book
{
    string name;
    int price;
    int quantity;
};

struct User
{
    string name;
    int saipID;
    int borrowedCount;
    int totalBill;
};

Book books[] =
{
    {"C++ Programming", 500,2},
    {"Mathematic", 600,2},
    {"English", 900, 2},
    {"Islamic", 700, 2},
    {"Novel", 800, 2},
    {"Tafseer Quran",600,2},
    {"Hadith Books",500,3}
};
int book_count=7;

User users[100] =
{
    {"ANAS Khan", 73401, 2, 1900},
    {"Fakhir Ashar", 73402, 1, 1200},
    {"Mahboob", 73403, 3, 2600}
};

int user_count = 3;

void view_all_books()
{
    cout << "**---------------- All Books ----------------**"<<endl;
    for (int i = 0; i < book_count; i++)
    {
        cout <<"Book:" <<books[i].name
        << " || Price: " << books[i].price
        << " || Quantity: " << books[i].quantity << endl;
    }
}

void view_available_books()
{
    cout << "**------------ Available Books ------------------**"<<endl;
    for (int i = 0; i < book_count; i++)
    {
        if (books[i].quantity > 0)
        {
            cout << books[i].name 
            << " || Quantity:"<< books[i].quantity <<endl;
        }
    }
}

void view_user_record()
{
    cout << "**-------------- User Record ----------------**"<<endl;
    for (int i = 0; i < user_count; i++)
    {
        cout << users[i].name
             << " || SAIP ID: " << users[i].saipID
             << " || Books Borrowed: " << users[i].borrowedCount << endl;
    }
}

void add_book()
{
    cout<<"**----------------Add Books--------------**"<<endl;
    if (book_count >= 15)
    {
        cout << "Book storage full\n";
        return;
    }

    cout << "Enter Book Name : ";
    cin >> books[book_count].name;

    cout << "Enter Book Price: ";
    cin >> books[book_count].price;

    cout << "Enter Quantity: ";
    cin >> books[book_count].quantity;

    book_count++;
    cout << "Book Added Successfully\n";
}

void remove_book()
{
    cout<<"**------------------Remove Book-------------------**"<<endl;
    string book_name;
    cout << "Enter Book Name to Remove: ";
    cin >> book_name;
    int remove=0;

    for (int i = 0; i < book_count; i++)
    {
        if (books[i].name == book_name)
        {
            for (int j = i; j < book_count- 1; j++)
            {
                books[j] = books[j + 1];
            }

            book_count--;
            remove=1;
            break;
        }
    }
    if(remove==1)
    {
        cout<<"Book removed Successfully"<<endl;
    }
    else
    {
        cout<<"Book not found"<<endl;
    }
}

void update_book()
{
    cout << "**-------------Update Book Details-------------**" << endl;

    string book_name;
    cout << "Enter Book Name: ";
    cin >> book_name;

    int remove = 0;
    int choice;

    for (int i = 0; i < book_count; i++)
    {
        if (books[i].name == book_name)
        {
            remove = 1;

            cout << "1. Update Price of book" << endl;
            cout << "2. Update number of book" << endl;
            cout << "Enter your choice: ";
            cin >> choice;

            switch (choice)
            {
            case 1:
                cout << "Enter New Price of book: ";
                cin >> books[i].price;
                cout << "Price Updated Successfully" << endl;
                break;

            case 2:
                cout << "Enter number of books: ";
                cin >> books[i].quantity;
                cout << "Quantity Updated Successfully" << endl;
                cout<<endl;
                break;

            default:
                cout << "Invalid Choice" << endl;
            }
            break;
        }
    }

    if (remove == 0)
    {
        cout << "Book not found" << endl;
    }
}



int main()
{
    cout<<"**---------------Library Management--------------**"<<endl;
    int choice,sub_choice;
    do
    {
        cout<<"1. Admin "<<endl<<"2. User"<<endl<<"3. Exit"<<endl;
        cout<<"Enter your choice"<<endl;
        cin>>choice;
        cout<<endl;
        switch(choice)
        {
            case 1:
            {
            
                int correct_password=123,password;
                int attempts=3;
                for(int i=attempts;i>0;i--)
                {
                    cout<<"Enter your password"<<endl;
                    cin>>password;
                    if(password==correct_password)
                    {
                        cout<<"Logged in succeesfully"<<endl;
                        cout<<endl;  
                        do
                        {
                            cout<<"1. View all Books"<<endl<<"2. View Books available"<<endl<<"3. View User Records"<<endl<<"4. Add new books"<<endl<<"5. Remove Books"<<endl<<"6. Update Book Details"<<endl;
                            cout<<"7. Back to main menu"<<endl;
                            cout<<"Enter what you want"<<endl;
                            cin>>sub_choice;
                            cout<<endl;
                            switch(sub_choice)
                            { 
                                case 1:
                                view_all_books();
                                cout<<endl;
                                break;
                                case 2:
                                view_available_books();
                                cout<<endl;
                                break;
                                case 3:
                                view_user_record();
                                cout<<endl;
                                break;
                                case 4:
                                add_book();
                                cout<<endl;
                                break;
                                case 5:
                                remove_book();
                                cout<<endl;
                                break;
                                case 6:
                                update_book();
                                cout<<endl;
                                break;
                                case 7:
                                cout<<"Return to main menu"<<endl;
                                cout<<endl;
                                break;
                                default:
                                cout<<"Invalid"<<endl;
                            }
                        }
                        while(sub_choice!=7);
                        break;    
                        
                    
                    }
                    else
                    {
                        cout<<"Incorrect password try again"<<endl;
                    }
                    
                }
            } 
            break;
            case 2:
            {
                do
                {
                    User new_user;
                    cout<<"Enter your Name:"<<endl;
                    cin>>new_user.name;
                    cout<<"Enter Your Saip id:"<<endl;
                    cin>>new_user.saipID;
                    users[user_count] =new_user;
                    user_count++;


                    cout<<"1. Borrow Book "<<endl<<"2. Return Book "<<endl<<"3. Check History "<<endl<<"4. Return to main menu"<<endl;
                    cout<<"Enter your choice"<<endl;
                    cin>>sub_choice;
                    cout<<endl;
                    switch(sub_choice)
                
                    {

                        case 1:
                        
                        break;
                        case 2:
                        cout<<"Enter the name of book"<<endl;
                        cout<<endl;
                        break;
                        case 3:
                        cout<<"Book 1 : 22-Feb-2025"<<endl<<"Book 2 : 3-jan-2025"<<endl;
                        cout<<endl;
                        break;
                        case 4:
                        cout<<"Return to main menu"<<endl;
                        cout<<endl;
                        break;
                        default:
                        cout<<"Invalid"<<endl;
                        
                    }
                }
                while(sub_choice!=4);
                break;
            }
            break;
            case 3:
            cout<<"Thankyou for using this application"<<endl;
            break;
            default:
            cout<<"Invalid"<<endl;       
        }
    } 
    while(choice!=3);       

 return 0;
}