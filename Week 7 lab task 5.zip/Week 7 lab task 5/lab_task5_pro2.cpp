#include<iostream>
using namespace std;
int main()
{
    for(int i=1;i<=5;i++)
    {
        
        
            cout<<"A    B   C   D   E";
        
        cout<<endl;
    }
 return 0;
}