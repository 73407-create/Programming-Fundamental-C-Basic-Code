#include<iostream>
using namespace std;
int main()
{
    
    for(int i=10;i<=40;i=i+10)
    {
        for(int j=1;j<=4;j++)
        {
            cout<<i+j<<'\t';
        }
        cout<<endl;       
    }


 return 0;
}