#include<iostream>
using namespace std;
int main()
{
    float sub1,sub2,sub3,sub4,sub5,obtained_marks,percentage;
    cout<<"Enter the marks of subject 1:"<<endl;
    cin>>sub1;
    cout<<"Enter the marks of subject 2:"<<endl;
    cin>>sub2;
    cout<<"Enter the marks of subject 3:"<<endl;
    cin>>sub3;
    cout<<"Enter the marks of subject 4:"<<endl;
    cin>>sub4;
    cout<<"Enter the marks of subject 5:"<<endl;
    cin>>sub5;
    obtained_marks=sub1+sub2+sub3+sub4+sub5;
    percentage=obtained_marks/500*100;
    cout<<"Obtained marks from all subjects:"<< obtained_marks<<endl;
    cout<<"Percentage of all subjects:"<<percentage <<endl;
 return 0;
}