#include<iostream>
using namespace std;
int main()
{
    int length ,width, height,volume;
    cout<<"Enter the length:"<<endl;
    cin>>length;
    cout<<"Enter the width:"<<endl;
    cin>>width;
    cout<<"Enter the Height:"<<endl;
    cin>>height;
    volume=length *width* height;
    cout<<"Volume of the cube:"<<volume<<endl;
 return 0;
}