#include<iostream>
using namespace std;
int main()
{
float    Fahrenheit,Celsius;
    cout<<"Temperature in Fahrenheit:"<<endl;
    cin>>Fahrenheit;
    Celsius=(5.0/9.0)*(Fahrenheit-32);
    cout<<"Temperature in celsius:"<<Celsius<<endl;
 return 0;
}