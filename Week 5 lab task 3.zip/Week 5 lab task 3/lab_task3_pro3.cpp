#include<iostream>
using namespace std;
int main()
{
    cout<<"Abuhuraira shamraiz,73407"<<endl;
    float num1,num2;
    cout<<"Enter first number:"<<endl;
    cin>>num1;
     cout<<"Enter second number:"<<endl;
     cin>>num2;
     if(num2=num1*num1)
     {
        cout<<"Second number is square of first number:"<<endl;
     }
 return 0;
}