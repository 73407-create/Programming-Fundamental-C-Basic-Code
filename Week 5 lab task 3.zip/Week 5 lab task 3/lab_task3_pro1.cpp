#include<iostream>
using namespace std;
int main()
{
  cout<<"Abuhuraira shamraiz,73407"<<endl;
  int num1=5;
  int num2=6;
  cout<<"Enter the first number:"<<num1<<endl;
  cout<<"Enter the second number:"<<num2<<endl;
  cout<<"The values after swaping are"<<endl;
  int num3;
  num3=num2;
  num2=num1;
  num1=num3;
  cout<<"The value of first number:"<<num1<<endl;
  
  cout<<"The value of second number"<<num2<<endl;

 return 0;
}