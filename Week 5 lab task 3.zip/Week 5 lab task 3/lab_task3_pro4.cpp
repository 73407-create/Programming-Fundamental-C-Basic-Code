#include<iostream>
using namespace std;
int main()
{
    cout<<"Abuhuraira shamraiz,73407"<<endl;
    int number;
    cout<<"Enter the number:"<<endl;
    cin>>number;
    if(number%2==0)
       {
        cout<<"Number is even"<<endl;
       }
       else{
    cout<<"Number is odd"<<endl;
       }  
 return 0;
}