#include<iostream>
using namespace std;
int main()
{
    cout<<"Abuhuraira shamraiz,73407"<<endl;
    float sub1,sub2,sub3;
    cout<<"Enter the marks of subject 1:"<<endl;
    cin>>sub1;
    cout<<"Enter the marks of subject 2:"<<endl;
     cin>>sub2;
    cout<<"Enter the marks of subject 3:"<<endl;
     cin>>sub3;
     int sum=sub1+sub2+sub3;
     cout<<"Sum of subjects"<<sum<<endl;
     float average=sum/3;
     cout<<"Average of marks is:"<<average<<endl;
     if(average>80)
     {
        cout<<"You are above standard"<<endl;
        cout<<"Admission Granted"<<endl;
     }
 return 0;
}