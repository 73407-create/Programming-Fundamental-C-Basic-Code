#include<iostream>
using namespace std;
int main()
{
    cout<<"Abuhuraira shamraiz,73407"<<endl;
    int number;
    cout<<"Enter the number:"<<endl;
    cin>>number;
    if(number>0)
    {
       cout<<" number is positive"<<endl;
    } 
       if(number<0)
       {
        cout<<"Number is negative"<<endl;
       }
       if(number==0)
      { 
        cout<<"number is zero"<<endl;
      }
 return 0;
}