#include<iostream>
using namespace std;
int main()
{
    cout<<"Abuhuraira shamraiz,73407"<<endl;
    int num1,num2,num3;
    cout<<"Enter the number 1:"<<endl;
    cin>>num1;
    cout<<"Enter the number 2:"<<endl;
    cin>>num2;
    cout<<"Enter the number 3:"<<endl;
    cin>>num3;
    cout<<"The maximum number is"<<endl;

    if(num1>num2&&num1>num3)
    {
        cout<<num1;
    }
    if(num2>num1&&num2>num3)
    {
        cout<<num2;
    }
    if(num3>num1&&num3>num2)
    {
        cout<<num3;
    }
 return 0;

}