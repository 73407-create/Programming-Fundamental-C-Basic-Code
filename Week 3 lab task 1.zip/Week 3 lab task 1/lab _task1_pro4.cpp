#include<iostream>
using namespace std;
int main()
{
    cout<<"AbuHuraira Shamraiz,Saip id 73407"<<endl;
    int  students,fee,total_fee ;
    cout<<"Total number of students in class:"<<endl;
    cin>>students;
    cout<<" Fee per  student in class:"<<endl;
    cin>>fee;
    total_fee=students*fee;
    cout<<"Total fee of students in class:"<<total_fee<<endl;
    
 return 0;
}