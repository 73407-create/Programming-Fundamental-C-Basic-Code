#include<iostream>
using namespace std;
int main()
{
    cout<<"AbuHuraira Shamraiz,Saip id 73407"<<endl;
    float miles,kilometers;
    cout<<"The distance in miles is :"<<endl;
    cin>>miles;
    kilometers=miles*1.069;
    cout<<"The distance of miles in kilometers:"<<kilometers<<endl;

 return 0;
}