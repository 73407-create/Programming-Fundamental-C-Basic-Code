#include<iostream>
using namespace std;
int main()
{
    cout<<"AbuHuraira Shamraiz,Saip id 73407"<<endl;
    int years , months ,days;
    cout<<"Age in years is: "<<endl;
    cin>>years;
    months =years*12;
    cout<<"The age in months is:"<<months<<endl;
    days =years*365;
    cout<<"The age in days is:"<<days<<endl;
 return 0;
}