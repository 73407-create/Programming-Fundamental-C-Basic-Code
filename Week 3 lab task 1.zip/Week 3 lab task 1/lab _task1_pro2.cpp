#include<iostream>
using namespace std;
int main()
{
    cout<<"AbuHuraira Shamraiz,Saip id 73407"<<endl;
    int a,b,c,d;
    cout<<"Enter first number:"<<endl;
    cin>>a;
    cout<<"Enter second number:"<<endl;
    cin>>b;
    cout<<"Enter third number:"<<endl;
    cin>>c;
    cout<<"Enter fourth number:"<<endl;
    cin>>d;
    int sum=a+b+c+d;
    cout<<"The sum of numbers is:"<<sum<<endl;
    int product=a*b*c*d;
    cout<<"The product of numbers is:"<<product<<endl;
    int average=sum/4;
    cout<<"The average of numbers is:"<<average<<endl;
 return 0;
}